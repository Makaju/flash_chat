import 'dart:developer';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flash_chat/decision_tree.dart';
import 'package:flash_chat/modules/local_push_notification.dart';
import 'package:flash_chat/screens/registration_page/registration_screen.dart';
import 'package:flash_chat/screens/welcome_screen/welcome_screen.dart';
import 'package:flash_chat/tempLogin.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'modules/theme/theme_provider.dart';
import 'package:timezone/data/latest.dart' as tz;

Future<void> _firebaseMessageBackgroundHandler (RemoteMessage message) async{
  //on click listner
}

void main() async {
  tz.initializeTimeZones();
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  LocalNotificationService.initialize();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessageBackgroundHandler);
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) => ChangeNotifierProvider(
        create: (context) => ThemeProvider(),
        builder: (context, _) {
          return Sizer(builder: (context, orientation, deviceType) {
            {
              return MaterialApp(
                debugShowCheckedModeBanner: false,
                title: 'Flash Chat',
                themeMode: Provider.of<ThemeProvider>(context).themeMode,
                theme: MyThemes.lightTheme,
                darkTheme: MyThemes.darkTheme,
                initialRoute: WelcomeScreen.id,
                routes: {
                  WelcomeScreen.id: (context) => DecisionTree(),
                  // LoginScreen.id: (context) => const LoginScreen(),
                  RegistrationScreen.id: (context) =>
                      const RegistrationScreen(),
                },
              );
            }
          });
        },
      );

// Widget build(BuildContext context) {
//   return MaterialApp(
//     debugShowCheckedModeBanner: false,
//     title: 'Main Page',
//     initialRoute: WelcomeScreen.id,
//     routes: {
//       WelcomeScreen.id: (context) => const WelcomeScreen(),
//       LoginScreen.id: (context) => const LoginScreen(),
//       RegistrationScreen.id: (context) => const RegistrationScreen(),
//       ChatScreen.id: (context) => const ChatScreen(
//             toWhom: 'apple@banana.com',
//           ),
//     },
//   );
// }
}

