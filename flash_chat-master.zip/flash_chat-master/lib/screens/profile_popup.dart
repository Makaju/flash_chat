import 'package:flash_chat/screens/landing_page/profile_page/profile_page.dart';
import 'package:flutter/material.dart';
import '../modules/global_variables.dart';

Widget popupProfile(String usersName,String userEmail) {

  return Container(
    padding: const EdgeInsets.only(top: 100),
    child: Dialog(
        backgroundColor: const Color(0xFFf3e5f5),
        shape:
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(4.0)),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            SizedBox(
              // color: Color(0x51e1bee1),
              height: 300,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 140, 10, 10),
                child: Column(
                  children: [
                    Text(
                      usersName.toString(),
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 20),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      loggedInUser.email.toString(),
                      style: const TextStyle(fontSize: 20),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //         builder: (context) => LandingPage(
                        //           screen: 1,
                        //         )));
                      },
                      child: const Text(
                        'Okay',
                        style: TextStyle(color: Colors.white),
                      ),
                    )
                  ],
                ),
              ),
            ),
            Positioned(
              top: -96,
              child: Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.white, width: 5),
                        color: const Color(0xCA4a148c),
                        shape: BoxShape.circle),
                    child: profilePictureWidget(
                        userEmail.toString().replaceAll('.', '') +
                            '.jpg',
                        96.0),
                  ),
                  Positioned(
                      bottom: 5,
                      right: 5,
                      child: InkWell(
                          onTap: () {
                            // showModalBottomSheet(
                            //     context: context,
                            //     builder: ((builder) => bottomSheet(context)));
                          },
                          child: Container(
                            height: 45,
                            width: 45,
                            decoration: BoxDecoration(
                                border:
                                Border.all(color: Colors.white, width: 3),
                                color: const Color(0xCA4a148c),
                                shape: BoxShape.circle),
                            child: const Icon(
                              Icons.edit,
                              color: Colors.white,
                            ),
                          ))),
                ],
              ),
            ),
          ],
        )),
  );
}
