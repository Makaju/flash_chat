import 'package:flash_chat/screens/welcome_screen/welcome_screen_buttons.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import '../../modules/constants.dart';
import '../../modules/database.dart';
import '../../modules/theme/theme_provider.dart';
import '../registration_page/registration_screen.dart';
import '../welcome_screen/forgot_password_page.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);
  static const String id = 'welcome_screen';

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool spinner = false;
  late String email;
  late String password;
  final Signin _signin = Signin();
  bool isDarkModeDemo = false;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  themeGetter() {
    if (Provider.of<ThemeProvider>(context).themeMode == ThemeMode.dark) {
      isDarkModeDemo = true;
      return true;
    } else if (Provider.of<ThemeProvider>(context).themeMode !=
        ThemeMode.dark) {
      isDarkModeDemo = false;
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Image(
          image: const AssetImage(
            "images/welcome.jpg",
          ),
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          fit: BoxFit.cover,
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 150),
              child: Container(
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius:
                    const BorderRadius.only(topLeft: Radius.circular(80))),
                child: ModalProgressHUD(
                  inAsyncCall: spinner,
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(
                            height: 100.0,
                          ),
                          Container(
                            decoration: BoxDecoration(
                                color: themeProvider.isDarkMode == true
                                    ? Colors.transparent
                                    : const Color(0x22424242),
                                borderRadius: BorderRadius.circular(15.0)),
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Email',
                                    style: TextStyle(
                                        color: Theme.of(context)
                                            .textTheme
                                            .headline1
                                            ?.color),
                                  ),
                                  TextField(
                                    controller: emailController,
                                    keyboardType: TextInputType.emailAddress,
                                    textAlign: TextAlign.left,
                                    onChanged: (value) {
                                      email = value;
                                      //Do something with the user input.
                                    },
                                    decoration: kLightTextField.copyWith(
                                        contentPadding:
                                        const EdgeInsets.only(top: 16),
                                        prefixIcon: const Icon(Icons.email),
                                        hintText: 'Enter your Email',
                                        hintStyle: TextStyle(
                                            color: Theme.of(context)
                                                .textTheme
                                                .headline1
                                                ?.color
                                                ?.withOpacity(0.5))),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 24.0,
                          ),
                          Container(
                            decoration: BoxDecoration(
                                color: themeProvider.isDarkMode == true
                                    ? Colors.transparent
                                    : const Color(0x22424242),
                                borderRadius: BorderRadius.circular(15.0)),
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Password',
                                    style: TextStyle(
                                      color: Theme.of(context)
                                          .textTheme
                                          .headline1
                                          ?.color,
                                    ),
                                  ),
                                  TextFormField(
                                    obscureText: true,
                                    controller: passwordController,
                                    textAlign: TextAlign.left,
                                    onChanged: (value) {
                                      password = value;
                                      //Do something with the user input.
                                    },
                                    decoration: kLightTextField.copyWith(
                                        contentPadding:
                                        const EdgeInsets.only(top: 16),
                                        prefixIcon: const Icon(Icons.lock),
                                        hintText: 'Enter your Password',
                                        hintStyle: TextStyle(
                                            color: Theme.of(context)
                                                .textTheme
                                                .headline1
                                                ?.color
                                                ?.withOpacity(0.5))),
                                    autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                    validator: (value) {
                                      if (passwordController.text.length > 6) {
                                        if (value == null ||
                                            value.isEmpty ||
                                            value.length < 6) {
                                          return 'please provide a password with more than 6 characters';
                                        } else {
                                          return null;
                                        }
                                      } else {
                                        return null;
                                      }
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 24.0,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              const Text('Login'),
                              loginButton(context),
                            ],
                          ),
                          TextButtonForgotSignin(
                            option: 'Forgot Password',
                            screen: const ForgotPasswordScreen(),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Not a registered user?',
                                style: TextStyle(
                                    color: Theme.of(context)
                                        .textTheme
                                        .headline1
                                        ?.color),
                              ),
                              TextButtonForgotSignin(
                                  option: 'Sign Up',
                                  screen: const RegistrationScreen())
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        )
      ],
    );
  }

  Padding loginButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Container(
        width: 100,
        height: 50,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Material(
          color: const Color(0xFF1a0c89),
          borderRadius: const BorderRadius.all(Radius.circular(15.0)),
          elevation: 5.0,
          child: MaterialButton(
            onPressed: () async {
              if (emailController.text == '' ||
                  passwordController.text == '') {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    backgroundColor: isDarkModeDemo
                        ? Colors.grey.shade700
                        : Colors.grey.shade500,
                    content: Text(
                      'Please provide email and password',
                      style: GoogleFonts.lato(
                          textStyle: TextStyle(
                              color: Theme.of(context)
                                  .textTheme
                                  .headline1
                                  ?.color)),
                    )));
              }else{
                setState(() {
                  spinner = true;
                });
                await _signin.signIn(email, password, context);
                spinner = false;
                //Implement registration functionality.
              }

            },
            // minWidth: 200.0,
            height: 36.0,
            child: const Icon(Icons.east, color: Colors.white),
          ),
        ),
      ),
    );
  }
}
