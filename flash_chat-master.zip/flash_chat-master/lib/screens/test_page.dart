import 'package:flash_chat/screens/landing_page/add_new_contact/add_new_contact.dart';
import 'package:flash_chat/screens/chat_screen/chat_screen.dart';
import 'package:flash_chat/screens/landing_page/contact_list/contact_list.dart';
import 'package:flash_chat/screens/welcome_screen/forgot_password_page.dart';
import 'package:flash_chat/screens/landing_page/inbox/inbox.dart';
import 'package:flash_chat/screens/landing_page/profile_page/profile_page.dart';
import 'package:flutter/material.dart';
import 'landing_page/profile_page/change_password.dart';
import 'landing_page/contact_list/edit_contacts.dart';

class TestPage extends StatefulWidget {
  const TestPage({Key? key}) : super(key: key);

  @override
  State<TestPage> createState() => _TestPageState();
}

class _TestPageState extends State<TestPage> {
  bool spinner = true;
  List filteredContacts = [];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: const Text('test page'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            //chat screen demo
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                ChatScreen( chatRoomId: 'YUwBk9Abo1xSYFKqLNHw', users: const ['sita@email.com','ram@email.com'], )));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Chat Screen Demo',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //stream test
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) =>ChatScreenDemo()));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Stream Test',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //contact list
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ContactList()));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Contact List',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //Inbox
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => const Inbox()));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'InboxRevised',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //Chat Screen
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                ChatScreen( chatRoomId: 'bGTCjwfwX1fLYeTAXCl8', users: const ['hari@email.com','sita@email.com'],)));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Chat Screen',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //Add Image Screen
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const ProfilePage()));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Add Image Screen',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //Add New COntact
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const AddNewContact()));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Add New COntact',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //New Inbox
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const Inbox(),
                        ));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'New Inbox',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //Forgot Password
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const ForgotPasswordScreen()));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Forgot Password',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //Inbox Revised
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const Inbox()));
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Inbox Revised',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //show dialogbox
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (_) {
                          return const ChangePasswordPopUp();
                        });
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Show Dialog box',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            //contact edit dialog box
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Material(
                color: Colors.blueAccent,
                borderRadius: const BorderRadius.all(Radius.circular(30.0)),
                elevation: 5.0,
                child: MaterialButton(
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (_) {
                          return EditContact(
                            contactno: '432423454',
                            email: 'ram@email.com',
                            nickname: 'Ram',
                            id: '2HAeMiKjyoYxlkHcPwL4',
                          );
                        });
                  },
                  minWidth: 200.0,
                  height: 42.0,
                  child: const Text(
                    'Show Edit contact popup',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ));
  }
}
