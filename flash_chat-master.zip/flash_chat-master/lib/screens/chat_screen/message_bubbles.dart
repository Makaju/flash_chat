import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flash_chat/modules/constants.dart';
import 'package:flash_chat/modules/database.dart';
import 'package:flutter/material.dart';
import '../../modules/global_variables.dart';

final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
List nameList=[];
class MyMessagesStream extends StatefulWidget {
  const MyMessagesStream({Key? key,required this.toWhom}) : super(key: key);
final String toWhom;

  @override
  State<MyMessagesStream> createState() => _MyMessagesStreamState();
}

class _MyMessagesStreamState extends State<MyMessagesStream> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUser();
    setState(() {
      getListOfContactDetails();

    });
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _fireStore
          .collection('messages')
          .orderBy('senttime', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(
            child: CircularProgressIndicator(
              backgroundColor: Colors.lightBlueAccent,
            ),
          );
        }

        final messages = snapshot.data!.docs.toList();
        List<MessageBubble> messageBubbles = [];
        for (var message in messages) {
          final messageText = message.get("messagetext");
          final messageSender = message.get('sender');
          final messageReceiver = message.get('sentto');
          // final senderNickame = messageReceivedFrom(messageSender);
          final currentUser = loggedInUser.email;
//todo this is to check and send messages related to current sender and reciever
          if (messageSender == loggedInUser.email.toString() ||
              messageSender == widget.toWhom) {
            if (messageReceiver == loggedInUser.email.toString() ||
                messageReceiver == widget.toWhom) {
              final messageBubble = MessageBubble(
                sender: messageSender,
                texts: messageText,
                isMe: currentUser == messageSender,
              );
              messageBubbles.add(messageBubble);
            }
          }
        }
        return ListView(
          reverse: true,
          children: messageBubbles,
        );

        // ListView.builder(
        // itemCount: messageWidgets.length,
        // shrinkWrap: true,
        // itemBuilder: (BuildContext context, int index) {
        //   return messageWidgets[index];
        // },
        // );

        // ListView.builder(
        //     itemCount: messageBubbles.length,
        //     itemBuilder: (context, index) {
        //       return Container(
        //         child: Text('hello222'),
        //       );
        //     });
        //
        // //   Column(
        //   children: messageWidgets,
        // );
      },
    );
  }
  Future<void> getListOfContactDetails() async {
    // await getUser();
    // Get docs from collection reference
    QuerySnapshot querySnapshot =
    await _fireStore.collection('contact_details').get();
    // Get data from docs and convert map to List
    setState(() {
      final allData = querySnapshot.docs.map((doc) {
        // if (doc["email"] == 'bananaman@apple.com') {
        // var key;
        // print("this is name: " + doc['nickname']);
        return doc.data();

        //}
      }) .toList();
      if(allData !=null || allData.isNotEmpty || allData != []){
        setState(() {
          nameList=allData.toList();
        });

        // print('this is namelist: $nameList');
      }
    });

    //var filteredData = filter(allData);


    // print("hello i am get con list "+ filteredData.toString());
    //  print(nameList);
  }
  String messageReceivedFrom(messageSender) {
    String nickname = messageSender;

    // senderName=_fireStore.collection('contact_details').snapshots(),

    StreamBuilder<QuerySnapshot>(
      stream: _fireStore.collection('contact_details').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          nickname = messageSender;
        } else if (snapshot.hasData) {
          // log("hello i am else fn");
          final contacts = snapshot.data!.docs.toList();
          for (var contact in contacts) {
            final senderEmail = contact.get("email");
            final senderName = contact.get("nickname");
            if (senderEmail == messageSender) {
              nickname = senderName;
              // log("hello i am sender" + senderName);
            } else {
              nickname = messageSender;
            }
          }
        }

        return Container();
      },
    );

    //if (nickname == messageSender) {
    //   return Text(messageSender, style: TextStyle(color: Colors.black54),)
    // ;}
    //else{return Text(nickname, style: TextStyle(color: Colors.black54),);}
    return nickname;
  }
}



getNickname(String senderEmail, String myEmail) {
  String nicknametoreturn = senderEmail;
  // print("name list aako cha ki chaina $nameList");
  log(nameList.length.toString());
if(nameList.isNotEmpty) {
  for (int i = 0; i < nameList.length; i++) {
    // print('this is inside getNickname ' + nameList[i]["email"]);
    //todo k milena milena

    log( nameList[i]['whose_contact'].toString());


    if (nameList[i]['whose_contact'] == myEmail &&
        nameList[i]['email'] == senderEmail) {

      nicknametoreturn = nameList[i]["nickname"];
      return nicknametoreturn;
      // return  nameList[i]["nickname"];
    }

  }
}
    // print('nickname to return is: $nicknametoreturn');
    return nicknametoreturn;

}

class MessageBubble extends StatelessWidget {
  MessageBubble(
      {Key? key, required this.sender, required this.texts, required this.isMe}) : super(key: key);

  String sender;
  String texts;
  bool isMe;
  BorderRadius isSender = const BorderRadius.only(
      topLeft: Radius.circular(30.0),
      bottomLeft: Radius.circular(30.0),
      bottomRight: Radius.circular(30.0));
  BorderRadius isReciever = const BorderRadius.only(
      topRight: Radius.circular(30.0),
      bottomLeft: Radius.circular(30.0),
      bottomRight: Radius.circular(30.0));

  @override
  Widget build(BuildContext context) {
    senderCheck()  {
      String senderEmail = sender;
      if (isMe == true) {
        return "Me";
      } else if(nameList != [] || nameList.isNotEmpty || nameList!=null ) {
        // print('this i return $nameList');
        return  getNickname(senderEmail, loggedInUser.email.toString());
      }
    }

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment:
            isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          //TODO bubble sender name
          Text(
            senderCheck(),
            style: const TextStyle(color: Colors.black54),
          ),
          // profilePictureWidget('sita@email.com', 10.0),
          Material(
            elevation: 5.0,
            borderRadius: isMe ? isSender : isReciever,
            color: isMe ? const Color(0xFF4a148c) : (themeProvider.isDarkMode?const Color(0xFF1b1b1b):Colors.white),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
              child: Text(
                texts,
                style: TextStyle(color: isMe ? Colors.white : (themeProvider.isDarkMode?Colors.white:Colors.black)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}


