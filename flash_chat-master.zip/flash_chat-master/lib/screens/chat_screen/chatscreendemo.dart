// import 'dart:developer';
// import 'dart:io';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flash_chat/screens/landing_page/profile_page/profile_page.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
// import '../../modules/global_variables.dart';
// import '../../modules/message_database.dart';
// import '../../modules/services.dart';
// import '../chat_screen/chat_screen.dart';
//
// class ChatScreenDemo extends StatefulWidget {
//   ChatScreenDemo({Key? key}) : super(key: key);
//
//   @override
//   State<ChatScreenDemo> createState() => _ChatScreenDemoState();
// }
//
// class _ChatScreenDemoState extends State<ChatScreenDemo> {
//   final DatabaseMethods _databaseMethods = DatabaseMethods();
//   final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: Container(
//           child: StreamBuilder<QuerySnapshot>(
//             stream: _fireStore
//                 .collection('chat_room')
//                 .doc('YUwBk9Abo1xSYFKqLNHw')
//                 .collection('chats')
//                 .orderBy('time', descending: true)
//                 .snapshots(),
//             builder: (context, snapshot) {
//               if (snapshot.hasData) {
//                 final messages = snapshot.data?.docs.toList();
//                 List<Widget> messageWidgets = [];
//                 for (var message in messages!) {
//                   final messageText = message.get('sender');
//                   final messageSender=message.get('message');
//                   final messagewidget = ContainerDemo(message: messageText, sender:messageSender,docId:'YUwBk9Abo1xSYFKqLNHw',);
//                   messageWidgets.add(messagewidget);
//                   // return Text(messageText.toString());
//                 }
//                 return Container(child: ListView(children: messageWidgets,),);
//               } else {
//                 return Container();
//               }
//             },
//           ),
//         ),
//       ),
//     );
//   }
// }
//
//
