import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import '../../../modules/constants.dart';
import '../../../modules/global_variables.dart';
import '../../../modules/theme/theme_provider.dart';
import '../landing_page.dart';
import '../profile_page/profile_page.dart';

class EditContact extends StatefulWidget {
  EditContact(
      {Key? key,
      required this.nickname,
      required this.email,
      required this.contactno,
      required this.id})
      : super(key: key);
  String nickname;
  String email;
  String contactno;
  String id;

  @override
  State<EditContact> createState() => _EditContactState();
}

class _EditContactState extends State<EditContact> {
  final emailEdit = TextEditingController();
  final nicknameEdit = TextEditingController();
  final contactnoEdit = TextEditingController();
  bool isDarkModeDemo=false;
@override
  void initState() {
    // TODO: implement initState
    super.initState();
    nicknameEdit.text=widget.nickname.toString();
    emailEdit.text =widget.email.toString();
    contactnoEdit.text=widget.contactno.toString();
  }
  themeGetter() {
    if (Provider.of<ThemeProvider>(context).themeMode == ThemeMode.dark) {
      isDarkModeDemo = true;
      return true;
    } else if (Provider.of<ThemeProvider>(context).themeMode !=
        ThemeMode.dark) {
      isDarkModeDemo = false;
      return false;
    }
  }
  @override
  Widget build(BuildContext context) {
  themeGetter();
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topCenter,
        children: [
          Container(
            decoration: BoxDecoration(
              color: isDarkModeDemo
                  ? Colors.grey.shade900
                  : Colors.white,
                borderRadius: BorderRadius.circular(15)

            ),
              height: 48.h,

              child: Padding(
                padding: EdgeInsets.only(top: 12.h),
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(1.h),
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(8)),
                        child: TextFormField(
                          controller: emailEdit,
                          style: TextStyle(color: Colors.black),
                          decoration: kTextfieldReImagined.copyWith(
                              prefixIcon: Icon(Icons.email,color:Colors.black),
                              hintText: 'Email'),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(1.h),
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(8)),
                        child: TextFormField(
                          style: TextStyle(color:Colors.black),
                          controller: nicknameEdit,
                          decoration: kTextfieldReImagined.copyWith(
                              prefixIcon: Icon(Icons.person,color:Colors.black),
                              hintText: 'Nickname'),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(1.h),
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(8)),
                        child: TextFormField(
                          controller: contactnoEdit,
                          style: TextStyle(color:Colors.black),
                          decoration: kTextfieldReImagined.copyWith(
                              prefixIcon: Icon(Icons.phone,color:Colors.black),
                              hintText: 'Contact Number'),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 1.h),
                      child: Material(
                        color: const Color(0xFF4a148c),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(8.0)),
                        elevation: 5.0,
                        child: MaterialButton(
                          onPressed: () {
                            final docUser = FirebaseFirestore.instance
                                .collection('contact_details')
                                .doc(widget.id.toString());
                            docUser.update({
                              'email': emailEdit.text,
                              'nickname': nicknameEdit.text,
                              'conact': contactnoEdit.text,
                            });

                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LandingPage(
                                          screen: 0,
                                        )));
                          },
                          child:  Text(
                            'Save',
                              style: GoogleFonts.lato(
                                  textStyle: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              )),
          Positioned(
            top: -12.h,
            child: Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.white, width: 5),
                      color: const Color(0xCA4a148c),
                      shape: BoxShape.circle),
                  child: profilePictureWidget(
                      loggedInUser.email.toString().replaceAll('.', '') +
                          '.jpg',
                      80.0),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
