import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../../modules/constants.dart';
import '../../../modules/theme/theme_provider.dart';
import '../landing_page.dart';

class AddNewContact extends StatefulWidget {
  const AddNewContact({Key? key}) : super(key: key);

  @override
  State<AddNewContact> createState() => _AddNewContactState();
}

class _AddNewContactState extends State<AddNewContact> {
  final messageTextController = TextEditingController();
  final _auth = FirebaseAuth.instance;
  late User loggedInUser;
  final newContactEmail = TextEditingController();
  final newContactNickname = TextEditingController();
  final newContactNumber = TextEditingController();
  bool isDarkModeDemo = false;
  final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
  List idList = [];

  themeGetter() {
    if (Provider.of<ThemeProvider>(context).themeMode == ThemeMode.dark) {
      isDarkModeDemo = true;
      return true;
    } else if (Provider.of<ThemeProvider>(context).themeMode !=
        ThemeMode.dark) {
      isDarkModeDemo = false;
      return false;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUser();
  }

  Future<void> getUser() async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        loggedInUser = user;
        // String userEmail = loggedInUser.email.toString();

      }
    } catch (e) {
      log(e.toString());
    }
  }

  isFriendStatusUpdater(String email) async {
    List users = [loggedInUser.email.toString(), email];
    users.sort((a, b) => a.compareTo(b));
    log(users.toString());
    QuerySnapshot querySnapshot = await _fireStore
        .collection('chat_room')
        .where('users', isEqualTo: users)
        .get();
    final allData = querySnapshot.docs.map((doc) {
      return doc.get('id');
    }).toList();
    if (allData != null || allData.isNotEmpty) {
      setState(() {
        idList = allData.toList();
      });
    }
    if(idList!=[]||idList.isNotEmpty){
      List newDataToAdd=[loggedInUser.email.toString()];
      final addToIsFriend = FirebaseFirestore.instance.collection('chat_room').doc(
          idList.first.toString()).update(
          {"isFriend": FieldValue.arrayUnion(newDataToAdd)});
      final removeFromIsNotFriend = FirebaseFirestore.instance.collection('chat_room').doc(
          idList.first.toString()).update(
          {"isNotFriend": FieldValue.delete()});


    }
  }

  @override
  Widget build(BuildContext context) {
    themeGetter();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              //email
              Padding(
                padding: const EdgeInsets.only(
                    top: 160, left: 16, right: 16, bottom: 8),
                child: Container(
                  decoration: BoxDecoration(
                      color: isDarkModeDemo
                          ? Colors.grey.shade900
                          : const Color(0x22424242),
                      borderRadius: BorderRadius.circular(15.0)),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Email',
                          style: GoogleFonts.lato(
                              textStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  color: Theme.of(context)
                                      .textTheme
                                      .headline1
                                      ?.color)),
                        ),
                        TextField(
                            controller: newContactEmail,
                            keyboardType: TextInputType.emailAddress,
                            textAlign: TextAlign.left,
                            onChanged: (value) {
                              //Do something with the user input.
                            },
                            decoration: kLightTextField.copyWith(
                              contentPadding: const EdgeInsets.only(top: 16),
                              prefixIcon: const Icon(Icons.email),
                              hintText: 'Enter your Email',
                              hintStyle: GoogleFonts.lato(
                                  textStyle: TextStyle(
                                      fontSize: 16,
                                      color: Theme.of(context)
                                          .textTheme
                                          .headline1
                                          ?.color
                                          ?.withOpacity(0.5))),
                            )),
                      ],
                    ),
                  ),
                ),
              ),
              //Nickname
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16),
                child: Container(
                  decoration: BoxDecoration(
                      color: isDarkModeDemo
                          ? Colors.grey.shade900
                          : const Color(0x22424242),
                      borderRadius: BorderRadius.circular(15.0)),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Nickname',
                          style: GoogleFonts.lato(
                              textStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  color: Theme.of(context)
                                      .textTheme
                                      .headline1
                                      ?.color)),
                        ),
                        TextField(
                            controller: newContactNickname,
                            keyboardType: TextInputType.text,
                            textAlign: TextAlign.left,
                            onChanged: (value) {
                              //Do something with the user input.
                            },
                            decoration: kLightTextField.copyWith(
                              contentPadding: const EdgeInsets.only(top: 16),
                              prefixIcon: const Icon(Icons.person),
                              hintText: 'Enter Nickname',
                              hintStyle: GoogleFonts.lato(
                                  textStyle: TextStyle(
                                      fontSize: 16,
                                      color: Theme.of(context)
                                          .textTheme
                                          .headline1
                                          ?.color
                                          ?.withOpacity(0.5))),
                            )),
                      ],
                    ),
                  ),
                ),
              ),
              //Contact number
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Container(
                  decoration: BoxDecoration(
                      color: isDarkModeDemo
                          ? Colors.grey.shade900
                          : const Color(0x22424242),
                      borderRadius: BorderRadius.circular(15.0)),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Contact number',
                          style: GoogleFonts.lato(
                              textStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  color: Theme.of(context)
                                      .textTheme
                                      .headline1
                                      ?.color)),
                        ),
                        TextField(
                          controller: newContactNumber,
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.left,
                          onChanged: (value) {
                            //Do something with the user input.
                          },
                          decoration: kLightTextField.copyWith(
                            contentPadding: const EdgeInsets.only(top: 16),
                            prefixIcon: const Icon(Icons.phone_android_sharp),
                            hintText: 'Enter Contact number',
                            hintStyle: GoogleFonts.lato(
                                textStyle: TextStyle(
                                    fontSize: 16,
                                    color: Theme.of(context)
                                        .textTheme
                                        .headline1
                                        ?.color
                                        ?.withOpacity(0.5))),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              //Button
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Container(
                  margin: const EdgeInsets.only(right: 20),
                  width: 95,
                  height: 50,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Material(
                    color: const Color(0xFF1a0c89),
                    borderRadius: const BorderRadius.all(Radius.circular(15.0)),
                    elevation: 5.0,
                    child: MaterialButton(
                      onPressed: () async {
                        //chat detector
                        //if chatroom cha bhane false lai true banaune natra do nothing
                        isFriendStatusUpdater(newContactEmail.text);

                        //todo continue from here
                        final docUser = FirebaseFirestore.instance
                            .collection('contact_details')
                            .doc();
                        final json = {
                          'id': docUser.id,
                          'email': newContactEmail.text,
                          'nickname': newContactNickname.text,
                          'contact': newContactNumber.text,
                          'whose_contact': loggedInUser.email.toString(),
                        };
                        await docUser.set(json);
                        messageTextController.clear();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LandingPage(
                                      screen: 0,
                                    )));
                      },
                      // minWidth: 200.0,
                      height: 36.0,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          Text(
                            'Save',
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
