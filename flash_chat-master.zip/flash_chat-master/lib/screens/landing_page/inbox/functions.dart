senderTitleRetreave(String sender,String reciever, String loggedinuseremail){
  if (sender.toString() ==
      loggedinuseremail.toString()) {
    return reciever;
  } else {
    return sender;
  }
}
