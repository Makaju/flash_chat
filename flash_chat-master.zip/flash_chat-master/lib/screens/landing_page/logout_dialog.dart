import 'package:firebase_auth/firebase_auth.dart';
import 'package:flash_chat/modules/global_variables.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../../modules/theme/theme_provider.dart';
import '../welcome_screen/welcome_screen.dart';

class LogoutDialog extends StatefulWidget {
  const LogoutDialog({Key? key}) : super(key: key);

  @override
  State<LogoutDialog> createState() => _LogoutDialogState();
}

class _LogoutDialogState extends State<LogoutDialog> {
  bool isDarkModeDemo = false;
  final secureStorage = const FlutterSecureStorage();


  themeGetter(BuildContext context) {
    if (Provider.of<ThemeProvider>(context).themeMode == ThemeMode.dark) {
      isDarkModeDemo = true;
      return true;
    } else if (Provider.of<ThemeProvider>(context).themeMode !=
        ThemeMode.dark) {
      isDarkModeDemo = false;
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    themeGetter(context);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(left: 40, right: 40, top: 300),
          child: Container(
            decoration: BoxDecoration(
                color: isDarkModeDemo
                    ? Colors.grey.shade800
                    : Colors.grey.shade100,
                borderRadius: BorderRadius.circular(30.0)),
            child: SizedBox(
              height: 168,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Column(
                  children: [
                    Text('Are you sure to logout?',
                        style: GoogleFonts.lato(
                            textStyle: TextStyle(
                                fontSize: 24,
                                color: isDarkModeDemo
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold))),
                    const SizedBox(
                      height: 26,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 40, vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Material(
                            color: Colors.green.shade500,
                            borderRadius:
                                const BorderRadius.all(Radius.circular(15.0)),
                            elevation: 5.0,
                            child: MaterialButton(
                              onPressed: () async {

                                await FirebaseAuth.instance.signOut();
                                await secureStorage.delete(key: "uName");
                                await secureStorage.delete(key: "pWord");
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            WelcomeScreen(onSignin: (User )=>null,)));
                                ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        backgroundColor: isDarkModeDemo
                                            ? Colors.grey.shade700
                                            : Colors.grey.shade500,
                                        content: Text(
                                          'Logged out succesfully',
                                          style: GoogleFonts.lato(
                                              textStyle: TextStyle(
                                                  color: Theme.of(context)
                                                      .textTheme
                                                      .headline1
                                                      ?.color)),
                                        )));
                              },
                              child: Text(
                                'Yes',
                                style: GoogleFonts.lato(
                                    textStyle: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold)),
                              ),
                            ),
                          ),
                          Material(
                              color: Colors.red.shade500,
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(15.0)),
                              elevation: 5.0,
                              child: MaterialButton(
                                onPressed: () {
                                  Navigator.pop(context, false);
                                },
                                child: Text('No',
                                    style: GoogleFonts.lato(
                                        textStyle: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold))),
                              )),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
