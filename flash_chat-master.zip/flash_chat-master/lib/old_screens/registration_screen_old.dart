// import 'dart:io';
// import 'package:path/path.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
// import 'package:path_provider/path_provider.dart';
// import '../modules/constants.dart';
//
// class RegistrationScreenOld extends StatefulWidget {
//   const RegistrationScreenOld({Key? key}) : super(key: key);
//   static const String id = 'registration_screen';
//
//   @override
//   _RegistrationScreenOldState createState() => _RegistrationScreenOldState();
// }
//
// class _RegistrationScreenOldState extends State<RegistrationScreenOld> {
//   late String email;
//   late String password;
//   late String userName;
//   late String phoneNo;
//   var _image;
//   var imagePicker;
//   final _auth = FirebaseAuth.instance;
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//   bool spinner = false;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           automaticallyImplyLeading: false,
//           title: const Text('Registration Screen'),
//         ),
//
//         body: SafeArea(
//           child: SingleChildScrollView(
//             child: Builder(
//               builder: (context) {
//                 return Container(
//                   height: MediaQuery.of(context).size.height*0.5,
//                   width: MediaQuery.of(context).size.width*1,
//                   child: ModalProgressHUD(
//                     inAsyncCall: spinner,
//                     child: Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           const SizedBox(height: 25.0,),
//                           Container(
//                             decoration: BoxDecoration(
//                                 color: isDarkMode?const Color(0x77424242) :Colors.transparent,
//                                 borderRadius: BorderRadius.circular(15.0)),
//                             child: TextField(
//                               textAlign: TextAlign.center,
//                               onChanged: (value) {
//                                 userName=value;
//                               },
//                               decoration: kTextfield.copyWith(hintText: 'Enter your Name'),
//                             ),
//                           ),
//                           const SizedBox(
//                             height: 8.0,
//                           ),
//                           Container(
//                             decoration: BoxDecoration(
//                                 color: isDarkMode?const Color(0x77424242) :Colors.transparent,
//                                 borderRadius: BorderRadius.circular(15.0)),
//                             child: TextField(
//                               keyboardType: TextInputType.number,
//                               textAlign: TextAlign.center,
//                               onChanged: (value) {
//                                 phoneNo=value;
//                               },
//                               decoration: kTextfield.copyWith(hintText: 'Enter your Phone Number'),
//                             ),
//                           ),
//                           const SizedBox(
//                             height: 8.0,
//                           ),
//                           Container(
//                             decoration: BoxDecoration(
//                                 color: Theme.of(context).colorScheme.onSecondary,
//                                 borderRadius: BorderRadius.circular(15.0)),
//                             child: TextField(
//                               keyboardType: TextInputType.emailAddress,
//                               textAlign: TextAlign.center,
//                               onChanged: (value) {
//                                 email = value;
//                                 //Do something with the user input.
//                               },
//                               decoration: kTextfield.copyWith(hintText: 'Enter your Email'),
//                             ),
//                           ),
//                           const SizedBox(
//                             height: 8.0,
//                           ),
//                           Container(
//                             decoration: BoxDecoration(
//                                 color:  isDarkMode?const Color(0x77424242) :Colors.transparent,
//                                 borderRadius: BorderRadius.circular(15.0)),
//                             child: TextField(
//                               textAlign: TextAlign.center,
//                               obscureText: true,
//                               onChanged: (value) {
//                                 password = value;
//                                 //Do something with the user input.
//                               },
//                               decoration:
//                               kTextfield.copyWith(hintText: 'Enter your Password'),
//                             ),
//                           ),
//                           const SizedBox(
//                             height: 24.0,
//                           ),
//                           Padding(
//                             padding: const EdgeInsets.symmetric(vertical: 16.0),
//                             child: Material(
//                               color: const Color(0xFF4a148c),
//                               borderRadius: const BorderRadius.all(Radius.circular(30.0)),
//                               elevation: 5.0,
//                               child: MaterialButton(
//                                 onPressed: () async {
//                                   setState(() {
//                                     spinner = true;
//                                   });
//                                   try {
//                                     final newUser =
//                                     await _auth.createUserWithEmailAndPassword(
//                                         email: email, password: password);
//                                     _firestore.collection('userdetails').add({'username':userName,'email':email,'phoneno':phoneNo});
//                                     if (newUser != null) {
//                                       // Navigator.pushNamed(context, LoginScreen.id);
//                                     }
//                                     setState(() {
//                                       spinner = false;
//                                     });
//                                   } on FirebaseAuthException catch (error) {
//                                     String errorMessage = error.message.toString();
//                                     setState(() {
//                                       spinner=false;
//                                     });
//                                     Fluttertoast.showToast(msg: errorMessage,gravity: ToastGravity.TOP);
//                                   }
//                                   //Implement registration functionality.
//                                 },
//                                 minWidth: 200.0,
//                                 height: 42.0,
//                                 child: const Text(
//                                   'Register',
//                                   style: TextStyle(color: Colors.white),
//                                 ),
//                               ),
//                             ),
//                           )
//                         ],
//                       ),
//                     ),
//                   ),
//                 );
//               }
//             ),
//           ),
//         ));
//   }
//   Widget profileImage(context) {
//     return Center(
//       child: Column(
//         children: [
//           Stack(
//             children: [
//               CircleAvatar(
//                 radius: 80.0,
//                 backgroundImage: _image == null
//                     ? const AssetImage('images/logo.png')
//                     : Image.file(_image).image,
//               ),
//               Positioned(
//                   bottom: 20,
//                   right: 30,
//                   child: InkWell(
//                       onTap: () {
//                         showModalBottomSheet(
//                             context: context, builder: ((builder) => bottomSheet(context)));
//                       },
//                       child: const Icon(
//                         Icons.camera_alt,
//                         color: Colors.black,
//                       ))),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
//   Widget bottomSheet(context) {
//     return Container(
//       height: 150,
//       width: MediaQuery.of(context).size.width,
//       margin: const EdgeInsets.symmetric(
//         horizontal: 20,
//         vertical: 20,
//       ),
//       child: Column(
//         children: [
//           const Text('Chose A profile Photo'),
//           const SizedBox(
//             height: 20,
//           ),
//           ElevatedButton(
//               onPressed: () async {
//                 XFile image =
//                 await imagePicker.pickImage(source: ImageSource.camera);
//                 setState(() {
//                   _image = File(image.path);
//                 });
//               },
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: const [
//                   Icon(Icons.camera_alt),
//                   Text('Add from Camera'),
//                 ],
//               )),
//           ElevatedButton(
//               onPressed: () async {
//                 XFile image =
//                 await imagePicker.pickImage(source: ImageSource.gallery);
//                 // final imagePermanently = saveImagePermanently(image.path);
//                 setState(() {
//                   _image = File(image.path);
//                 });
//               },
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: const [
//                   Icon(Icons.image),
//                   Text('Add From Gallery'),
//                 ],
//               )),
//         ],
//       ),
//     );
//   }
//   Future <File>saveImagePermanently(String imagePath)async{
//     final directory= await getApplicationDocumentsDirectory();
//     final name = basename(imagePath);
//     final image=File('${directory.path}/$name');
//     return  File(imagePath).copy(image.path);
//
//   }
// }
