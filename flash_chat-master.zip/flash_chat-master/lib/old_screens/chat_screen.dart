// import 'dart:developer';
//
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flash_chat/screens/landing_page/profile_page/profile_page.dart';
// import 'package:flutter/material.dart';
// import '../../modules/constants.dart';
// import '../../modules/refactored/get_doc_id_for_contactlist_addnewcontact.dart';
// import '../../modules/global_variables.dart';
// import '../../modules/theme/theme_provider.dart';
// import 'message_bubbles.dart';
//
//
// final _auth = FirebaseAuth.instance;
//
// late String messageText;
// final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
//
//
// class ChatScreen extends StatefulWidget {
//   const ChatScreen({Key? key,required this.toWhom}) : super(key: key);
//   static const String id = 'chat_screen';
//   final String toWhom;
//
//   @override
//   _ChatScreenState createState() => _ChatScreenState();
// }
//
// class _ChatScreenState extends State<ChatScreen> {
//   bool get isDarkMode=>ThemeProvider.themeMode==ThemeMode.dark;
//
//   final messageTextController = TextEditingController();
//
//
//
// //   Future<void> getMessages() async {
// //     QuerySnapshot querySnapshot = await _firestore.collection("messages").getDocuments();
// //     for (int i = 0; i < querySnapshot.messages.length; i++) {
// //       var a = querySnapshot.messages[i];
// //       print(a.documentID);
// //     }
// // }
//
//   Future<void> getUser() async {
//     try {
//       final user = _auth.currentUser;
//       if (user != null) {
//         loggedInUser = user;
//         // print(loggedInUser.email);
//       }
//     } catch (e) {
//       log(e.toString());
//     }
//   }
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     getUser();
//
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         automaticallyImplyLeading: false,
//         leading: null,
//         actions: <Widget>[
//           profilePictureWidget(widget.toWhom.replaceAll('.', '')+'.jpg', 24.0),
//           IconButton(
//               icon: const Icon(Icons.info_outline_rounded),
//               onPressed: () {
//                 // getNickname('bananaman@apple.com', 'apple@banana.com');
//                 // getNickname('bananaman@apple.com');
//                 // //Implement logout functionality
//               }),
//         ],
//         title: const Text('Receivers Name Here'),
//         backgroundColor: const Color(0xFF4a148c),
//       ),
//       body: SafeArea(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: <Widget>[
//             Expanded(
//               child: MyMessagesStream(toWhom: widget.toWhom,),
//             ),
//             MessageInputBox(isDarkMode: isDarkMode, messageTextController: messageTextController, widget: widget),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// class MessageInputBox extends StatelessWidget {
//   const MessageInputBox({
//     Key? key,
//     required this.isDarkMode,
//     required this.messageTextController,
//     required this.widget,
//   }) : super(key: key);
//
//   final bool isDarkMode;
//   final TextEditingController messageTextController;
//   final ChatScreen widget;
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.only(bottom: 15.0, left: 10.0, right: 10.0),
//       child: Container(
//         decoration:isDarkMode?kMessageContainerDecorationDark:kMessageContainerDecorationlight,
//         child: Row(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             Expanded(
//               child: TextField(
//                 controller: messageTextController,
//                 onChanged: (value) {
//                   messageText = value;
//                   //Do something with the user input.
//                 },
//                 decoration: kMessageTextFieldDecoration,
//               ),
//             ),
//             TextButton(
//               onPressed: () {
//                 messageTextController.clear();
//                 _fireStore.collection('messages').add(
//                   {
//                     'messagetext': messageText,
//                     'sender': loggedInUser.email,
//                     'senttime': DateTime.now(),
//                     'sentto': widget.toWhom
//                   },
//                 );
//               },
//               child: Icon(Icons.send, color: isDarkMode?Color(0xFF4a148c):const Color(0xFF4a148c),),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
//
//
//
