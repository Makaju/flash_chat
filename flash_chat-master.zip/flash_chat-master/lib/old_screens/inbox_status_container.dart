// import 'package:flash_chat/modules/refactored/get_doc_id_for_contactlist_addnewcontact.dart';
// import 'package:flash_chat/screens/chat_screen/chat_screen.dart';
// import 'package:flutter/material.dart';
//
// import '../../../modules/constants.dart';
// import '../../../modules/global_variables.dart';
// import '../../../modules/theme/theme_provider.dart';
// import '../../../old_screens/chat_screen.dart';
// import '../profile_page/profile_page.dart';
//
// class InboxContainer extends StatelessWidget {
//   InboxContainer({Key? key, required this.name, required this.message, required this.sender})
//       : super(key: key);
//
//   String name;
//   String message;
//   String sender;
//   bool get isDarkMode=>ThemeProvider.themeMode==ThemeMode.dark;
//
//
//   whoSent(){
//     if(sender==loggedInUser.email.toString()){
//       return Text('You: '+message);
//     }
//     else{
//       return Text(message);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.all(8.0),
//       child: GestureDetector(
//         onTap: () {
//           // Navigator.push(
//           //     context,
//           //     MaterialPageRoute(
//           //         builder: (context) => ChatScreeNew(
//           //         )));
//         },
//         child: Container(
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(10),
//             color:isDarkMode?Colors.black: Color(0xFFf5f5ff),
//           ),
//           padding: const EdgeInsets.all(8),
//           child: Row(
//             children: [
//               profilePictureWidget(name.replaceAll('.', '') + '.jpg', 20.0),
//               Padding(
//                 padding: const EdgeInsets.only(left: 15.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       name,
//                       style: const TextStyle(
//                           fontSize: 18.0, fontWeight: FontWeight.bold),
//                     ),
//                     whoSent(),
//                   ],
//                 ),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }