// import 'package:flash_chat/modules/database.dart';
// import 'package:flash_chat/screens/landing_page/profile_page/profile_page.dart';
// import 'package:flutter/material.dart';
// import '../modules/global_variables.dart';
// import 'landing_page/add_new_contact/add_new_contact.dart';
// import 'landing_page/contact_list/contact_list.dart';
// import 'landing_page/inbox/inbox_shell.dart';
//
// class NewLandingPage extends StatefulWidget {
//   NewLandingPage({Key? key, required this.screen}) : super(key: key);
//   int screen;
//
//   @override
//   State<NewLandingPage> createState() => _NewLandingPageState();
// }
//
// class _NewLandingPageState extends State<NewLandingPage> {
//   late int index;
//   bool spinner = true;
//
//   final screens = [
//     const ContactList(),
//     const InboxShell(),
//     const AddNewContact(),
//     const Center(child: ProfilePage()),
//   ];
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     index = widget.screen;
//     getInfo();
//     setState(() {});
//     getUsersName;
//   }
//   getInfo() async {
//     await getUser();
//     setState(() {
//       spinner = false;
//     });
//   }
//   String titleReturner() {
//     if (index == 0) {
//       return 'Contacts';
//     } else if (index == 1) {
//       return 'Inbox';
//     } else if (index == 3) {
//       return '';
//     } else {
//       return 'Add new contact';
//     }
//   }
//   Widget titlereturnercheck() {
//     if (titleReturner() != '' && titleReturner() != null) {
//       return Padding(
//         padding: const EdgeInsets.only(left: 16, bottom: 24, top: 16),
//         child: Text(
//           titleReturner().toString(),
//           style: const TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
//         ),
//       );
//     } else {
//       return Container();
//     }
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             titlereturnercheck(),
//             Expanded(
//                 child: Container(
//                   child: screens[index],
//                 )),
//           ],
//         ),
//       ),
//       bottomNavigationBar: NavigationBarTheme(
//         data: NavigationBarThemeData(
//             indicatorColor: Colors.purple.shade400,
//             labelTextStyle: MaterialStateProperty.all(
//                 const TextStyle(fontSize: 14, fontWeight: FontWeight.w500))),
//         child: NavigationBar(
//           selectedIndex: index,
//           height: 60,
//           onDestinationSelected: (index) =>
//               setState(() {
//                 this.index = index;
//               }),
//           destinations:  [
//             const NavigationDestination(
//                 icon: Icon(Icons.group_outlined), label: 'Contacts'),
//             const NavigationDestination(
//                 icon: Icon(Icons.email_outlined), label: 'Contacts'),
//             const NavigationDestination(
//                 icon: Icon(Icons.person_add_outlined), label: 'Contacts'),
//             NavigationDestination(
//                 icon: CircleAvatar(
//                   radius: 16,
//                   child: profilePictureWidget(
//                       loggedInUser.email.toString().replaceAll('.', '') + '.jpg',
//                       16.0),
//                 ),
//                 label: 'Contacts')
//           ],
//         ),
//       ),
//     );
//   }
// }
