// import 'dart:developer';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flash_chat/modules/constants.dart';
// import 'package:flash_chat/screens/chat_screen/chat_screen_for_the_unknown.dart';
// import 'package:flutter/material.dart';
// import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
// import 'package:flash_chat/screens/registration_page/storage_srvice.dart';
//
// import '../profile_page/profile_page.dart';
//
// class MessageFromTheUnknown extends StatefulWidget {
//   const MessageFromTheUnknown({Key? key}) : super(key: key);
//
//   @override
//   State<MessageFromTheUnknown> createState() => _MessageFromTheUnknownState();
// }
//
// class _MessageFromTheUnknownState extends State<MessageFromTheUnknown> {
//   final _auth = FirebaseAuth.instance;
//   final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
//   late User loggedInUser;
//   List friendList = [];
//   List emailList = [];
//   final Storage storage = Storage();
//   bool spinner = true;
//
//   Future getUser() async {
//     try {
//       final user = _auth.currentUser;
//       if (user != null) {
//         loggedInUser = user;
//
//         // print(loggedInUser.email);
//       }
//     } catch (e) {
//       log(e.toString());
//     }
//   }
//
//   @override
//   void initState() {
//     // TODO: implement initState
//
//     super.initState();
//     showSpinner();
//   }
//
//   showSpinner() async {
//     await getUser();
//     // print('this is to check ${loggedInUser.email.toString()}');
//     await getFriendsList().then((value) => getEmailList());
//     setState(() {
//       if (loggedInUser != null) {
//         spinner = false;
//       }
//     });
//     // print('got all data');
//   }
//
//   Future<void> getFriendsList() async {
//     // await getUser();
//     // Get docs from collection reference
//     QuerySnapshot querySnapshot = await _fireStore
//         .collection('contact_details')
//         .where('whose_contact', isEqualTo: loggedInUser.email)
//         .get();
//     // Get data from docs and convert map to List
//     final allData = querySnapshot.docs.map((doc) {
//       // if (doc["email"] == 'bananaman@apple.com') {
//       // var key;
//       // print("this is name: " + doc['nickname']);
//       return doc.data();
//
//       //}
//     }).toList();
//     //var filteredData = filter(allData);
//     if (allData != null || allData.isNotEmpty) {
//       setState(() {
//         friendList = allData.toList();
//       });
//       // print('this is namelist: $friendList');
//     }
//
//     // print("hello i am get con list "+ filteredData.toString());
//     //  print(nameList);
//   }
//
//   getEmailList() {
//     for (int i = 0; i < friendList.length; i++) {
//       final email = friendList[i]['email'];
//       emailList.add(email);
//       setState(() {});
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//
//         // appBar: AppBar(
//         //   title: Row(
//         //     children: [
//         //       Text('Inbox'),
//         //       IconButton(
//         //           icon: Icon(Icons.people),
//         //           onPressed: () {
//         //             Navigator.push(
//         //                 context, MaterialPageRoute(builder: (context) => TestPage()));
//         //           }),
//         //     ],
//         //   ),
//         // ),
//
//           body: ModalProgressHUD(
//             inAsyncCall: spinner,
//             child: (emailList != [])
//                 ? Column(
//               children: [
//                 StreamBuilder<QuerySnapshot>(
//                   stream: _fireStore
//                       .collection('messages')
//                       .where('sentto',
//                       isEqualTo: loggedInUser.email.toString())
//                       .orderBy('senttime', descending: true)
//                       .snapshots(),
//                   builder: (context, snapshot) {
//                     if (!snapshot.hasData) {
//                       return const Center(
//                         child: CircularProgressIndicator(
//                           backgroundColor: Colors.lightBlueAccent,
//                         ),
//                       );
//                     }
//                     final inboxMessage =
//                     snapshot.data!.docs.toList();
//                     List<Widget> inboxWidgets = [];
//                     List contactCount = [];
//
//                     for (var inbox in inboxMessage) {
//                       final messageText = inbox.get("messagetext");
//                       final messageSender = inbox.get('sender');
//                       // final messageReceiver = inbox.get('sentto');
//
// //todo mathiko if
// //                     if(messageReceiver.toString()==loggedInUser.email.toString()){
// //                       print('aairako cha ' +
// //                           loggedInUser.email.toString());
// //                       print('contactsssssss $emailList');
//
//                       if (emailList.contains(messageSender.toString())==false) {
//                         if ((contactCount
//                             .contains(messageSender)) ==
//                             false) {
//                           final inboxWidget = InboxContainder(
//                               name: messageSender,
//                               message: messageText);
//                           inboxWidgets.add(inboxWidget);
//                           contactCount
//                               .add(messageSender.toString());
//                           // print(
//                           //     'initial pachi add gareko $messageSender');
//                         }
//
//                         // final inboxWidget = Text('$messageText from $messageSender');
//                         // inboxWidgets.add(inboxWidget);
//                         // contactCount.add(messageSender.toString());
//                         // print('initial contact add agreko $contactCount');
//                       }
//                     }
//                     return Expanded(
//                         child: ListView(
//                           children: inboxWidgets,
//                         ));
//                   },
//                 ),
//               ],
//             )
//                 : Container(),
//           )),
//     );
//   }
// }
//
// class InboxContainder extends StatelessWidget {
//   InboxContainder({Key? key, required this.name, required this.message}) : super(key: key);
//
//   String name;
//   String message;
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.all(8.0),
//       child: GestureDetector(
//         onTap: () {
//           Navigator.push(
//               context,
//               MaterialPageRoute(
//                   builder: (context) => ChatScreenForTheUnknown(chatRoomId: '', users: [],
//                   )));
//         },
//         child: Container(
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(10),
//             color: isDarkMode?Colors.black:Color(0xFFf5f5ff),
//           ),
//           padding: const EdgeInsets.all(8),
//           child: Row(
//             children: [
//               profilePictureWidget(name.replaceAll('.', '') + '.jpg', 20.0),
//               Padding(
//                 padding: const EdgeInsets.only(left: 15.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   // mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     Text(
//                       name,
//                       style: const TextStyle(
//                           fontSize: 18.0, fontWeight: FontWeight.bold),
//                     ),
//                     Text(message),
//                   ],
//                 ),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// // Positioned(
// // bottom: 24.00,
// // right: 15.0,
// // child: GestureDetector(
// // onTap: () {
// // Navigator.push(
// // context,
// // MaterialPageRoute(
// // builder: (context) => TestPage()));
// // },
// // child: Container(
// // height: 60.0,
// // width: 60.0,
// // decoration: BoxDecoration(
// // gradient: LinearGradient(
// // colors: [
// // Colors.red,
// // Colors.redAccent,
// // ],
// // begin: Alignment(0.0, -1.0),
// // end: Alignment(0.0, 1.0),
// // ),
// // borderRadius: BorderRadius.circular(20.0),
// // ),
// // child: Icon(
// // Icons.add,
// // color: Colors.black,
// // ),
// // ),
// // ),
// // ),
