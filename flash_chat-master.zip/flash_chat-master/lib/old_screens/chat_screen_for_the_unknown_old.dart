// import 'dart:developer';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flash_chat/screens/landing_page/profile_page/profile_page.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import '../../modules/constants.dart';
// import '../../modules/global_variables.dart';
// import 'add_unknown_contact.dart';
// import 'message_bubbles.dart';
//
// final _auth = FirebaseAuth.instance;
//
// late String messageText;
// final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
//
//
// class ChatScreenForTheUnknown extends StatefulWidget {
//   const ChatScreenForTheUnknown({Key? key,required this.toWhom}) : super(key: key);
//   static const String id = 'chat_screen';
//   final String toWhom;
//
//   @override
//   _ChatScreenForTheUnknownState createState() => _ChatScreenForTheUnknownState();
// }
//
// class _ChatScreenForTheUnknownState extends State<ChatScreenForTheUnknown> {
//   final messageTextController = TextEditingController();
//
//
//
// //   Future<void> getMessages() async {
// //     QuerySnapshot querySnapshot = await _firestore.collection("messages").getDocuments();
// //     for (int i = 0; i < querySnapshot.messages.length; i++) {
// //       var a = querySnapshot.messages[i];
// //       print(a.documentID);
// //     }
// // }
//
//   Future<void> getUser() async {
//     try {
//       final user = _auth.currentUser;
//       if (user != null) {
//         loggedInUser = user;
//         // print(loggedInUser.email);
//       }
//     } catch (e) {
//       log(e.toString());
//     }
//   }
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     getUser();
//
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         automaticallyImplyLeading: false,
//         leading: null,
//         actions: <Widget>[
//           profilePictureWidget(widget.toWhom.replaceAll('.', '')+'.jpg', 24.0),
//           IconButton(
//               icon: const Icon(Icons.add),
//               onPressed: () {
//                 showDialog(
//                     context: context,
//                     builder: (BuildContext context) {
//                       return AddNewUnknownContact(widget.toWhom.toString());
//                     });
//               }),
//         ],
//         title: const Text('Receivers Name Here'),
//         backgroundColor: Colors.lightBlueAccent,
//       ),
//       body: SafeArea(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: <Widget>[
//             Expanded(
//               child: MyMessagesStream(toWhom: widget.toWhom,),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(bottom: 15.0, left: 10.0, right: 10.0),
//               child: Container(
//                 decoration: kMessageContainerDecorationlight,
//                 child: Row(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: <Widget>[
//                     Expanded(
//                       child: Container(
//                         decoration: BoxDecoration(
//                             color: isDarkMode?const Color(0x77424242) :Colors.transparent,
//                             borderRadius: BorderRadius.circular(15.0)),
//                         child: TextField(
//                           controller: messageTextController,
//                           onChanged: (value) {
//                             messageText = value;
//                             //Do something with the user input.
//                           },
//                           decoration: kMessageTextFieldDecoration,
//                         ),
//                       ),
//                     ),
//                     TextButton(
//                       onPressed: () {
//                         messageTextController.clear();
//                         if (kDebugMode) {
//                           print(messageText);
//                         }
//                         _fireStore.collection('messages').add(
//                           {
//                             'messagetext': messageText,
//                             'sender': loggedInUser.email,
//                             'senttime': DateTime.now(),
//                             'sentto': widget.toWhom
//                           },
//                         );
//                       },
//                       child: const Icon(Icons.send),
//                     )
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
//
//
