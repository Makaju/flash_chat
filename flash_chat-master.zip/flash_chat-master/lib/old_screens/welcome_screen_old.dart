// import 'package:animated_text_kit/animated_text_kit.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flash_chat/screens/welcome_screen/forgot_password_page.dart';
// import 'package:flash_chat/screens/landing_page/landing_page.dart';
// import 'package:flash_chat/old_screens/registration_screen_old.dart';
// import 'package:flash_chat/screens/welcome_screen/welcome_screen.dart';
// import 'package:flash_chat/screens/welcome_screen/welcome_screen_buttons.dart';
// import 'package:flutter/material.dart';
// import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
// import '../modules/constants.dart';
// import 'package:fluttertoast/fluttertoast.dart';
//
// import '../modules/database.dart';
//
// typedef GoToScreen = void Function();
//
// class WelcomeScreenOld extends StatefulWidget {
//   const WelcomeScreenOld({Key? key}) : super(key: key);
//   static const String id = 'old_screens';
//
//   @override
//   _WelcomeScreenOldState createState() => _WelcomeScreenOldState();
// }
//
// class _WelcomeScreenOldState extends State<WelcomeScreenOld> with SingleTickerProviderStateMixin {
//   late AnimationController controller;
//   late Animation animation;
//   bool spinner = false;
//   late String email;
//   late String password;
//   final _auth = FirebaseAuth.instance;
//   Signin _signin = Signin();
//   TextEditingController emailController=TextEditingController();
//   TextEditingController passwordController=TextEditingController();
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     _auth.signOut();
//     controller = AnimationController(
//       vsync: this,
//       duration: const Duration(seconds: 1),
//     );
//     animation = ColorTween(
//             begin: Colors.grey, end: isDarkMode ? Colors.black : Colors.white)
//         .animate(controller);
//     controller.forward();
//     controller.addListener(() {
//       setState(() {
//         //print(controller.value);
//       });
//     });
//   }
//
//   @override
//   void dispose() {
//     // TODO: implement dispose
//     controller.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // setState(() {
//     //   _auth.signOut();
//     // });
//     return Scaffold(
//       // backgroundColor: animation.value,
//       body: SafeArea(
//         child: ModalProgressHUD(
//           inAsyncCall: spinner,
//           child: SingleChildScrollView(
//             child: Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   const SizedBox(
//                     height: 100.0,
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Hero(
//                         tag: 'logo',
//                         child: SizedBox(
//                             width: 100,
//                             height: controller.value * 100,
//                             child: const Image(
//                                 image: AssetImage(
//                               'images/logo.png',
//                             ))),
//                       ),
//                       SizedBox(
//                         child: DefaultTextStyle(
//                           style: TextStyle(
//                             fontSize: 30.0,
//                             fontWeight: FontWeight.bold,
//                             color: isDarkMode ? Colors.white : Colors.black,
//                             fontFamily: 'Agne',
//                           ),
//                           child: AnimatedTextKit(
//                             animatedTexts: [
//                               TypewriterAnimatedText('Lets Chat'),
//                             ],
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   Container(
//                     decoration: BoxDecoration(
//                         color: isDarkMode
//                             ? const Color(0x77424242)
//                             : Colors.transparent,
//                         borderRadius: BorderRadius.circular(15.0)),
//                     child: TextField(
//                       controller: emailController,
//                       keyboardType: TextInputType.emailAddress,
//                       textAlign: TextAlign.center,
//                       onChanged: (value) {
//                         email = value;
//                         //Do something with the user input.
//                       },
//                       decoration: kTextfield.copyWith(
//                           hintText: 'Enter your Email',
//                           hintStyle: TextStyle(
//                               color: isDarkMode ? Colors.white : Colors.black)),
//                     ),
//                   ),
//                   const SizedBox(
//                     height: 8.0,
//                   ),
//                   Container(
//                     decoration: BoxDecoration(
//                         color: isDarkMode
//                             ? const Color(0x77424242)
//                             : Colors.transparent,
//                         borderRadius: BorderRadius.circular(15.0)),
//                     child: TextField(
//                       controller: passwordController,
//                       // validator: (value){
//                       //   if(value != ){
//                       //
//                       //   }
//                       // },
//
//                       textAlign: TextAlign.center,
//                       obscureText: true,
//                       onChanged: (value) {
//                         password = value;
//                         //Do something with the user input.
//                       },
//                       decoration: kTextfield.copyWith(
//                           hintText: 'Enter your Password',
//                           hintStyle: TextStyle(
//                               color: isDarkMode ? Colors.white : Colors.black)),
//                     ),
//                   ),
//                   const SizedBox(
//                     height: 24.0,
//                   ),
//                   loginButton(context),
//                   textButton_forgot_signin(option: 'Forgot Password', screen: const ForgotPasswordScreen(),),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Text(
//                         'Not a registered user?',
//                         style: TextStyle(
//                             color: isDarkMode ? Colors.white : Colors.black),
//                       ),
//                       textButton_forgot_signin(option: 'Sign Up', screen: const RegistrationScreenOld()),
//                       textButton_forgot_signin(option: 'Sign Up', screen: const WelcomeScreen())
//                     ],
//                   )
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Padding loginButton(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 16.0),
//       child: Container(
//         width: 50,
//         padding: const EdgeInsets.symmetric(horizontal: 120),
//         child: Material(
//           color: const Color(0xFF4a148c),
//           borderRadius: const BorderRadius.all(Radius.circular(30.0)),
//           elevation: 5.0,
//           child: MaterialButton(
//             onPressed: () async {
//               setState(() {
//                 spinner = true;
//               });
//               _signin.signIn(email, password, context);
//               // await Signin().signIn(email, password,context);
//               spinner = false;
//               //Implement registration functionality.
//             },
//             // minWidth: 200.0,
//             height: 42.0,
//             child: const Text(
//               'Login',
//               style: TextStyle(color: Colors.white),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
//
//
