// import 'dart:developer';
// import 'package:rxdart/rxdart.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
// import '../modules/global_variables.dart';
// import 'package:flash_chat/screens/registration_page/storage_srvice.dart';
// import '../screens/landing_page/inbox/inbox_status_container.dart';
//
// class Inbox extends StatefulWidget {
//   const Inbox({Key? key}) : super(key: key);
//
//   @override
//   State<Inbox> createState() => _InboxState();
// }
//
// class _InboxState extends State<Inbox> {
//   final _auth = FirebaseAuth.instance;
//   final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
//   List friendList = [];
//   List emailList = [];
//   final Storage storage = Storage();
//   bool spinner = true;
//   bool isItMe=false;
//
//   Future getUser() async {
//     try {
//       final user = _auth.currentUser;
//       if (user != null) {
//         loggedInUser = user;
//       }
//     } catch (e) {
//       log(e.toString());
//     }
//   }
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     showSpinner();
//   }
//
//   showSpinner() async {
//     await getUser();
//     // print('this is to check ${loggedInUser.email.toString()}');
//     await getFriendsList().then((value) => getEmailList());
//     setState(() {
//       if (loggedInUser != null) {
//         spinner = false;
//       }
//     });
//     // print('got all data');
//   }
//
//   Future<void> getFriendsList() async {
//     // await getUser();
//     // Get docs from collection reference
//     QuerySnapshot querySnapshot = await _fireStore
//         .collection('contact_details')
//         .where('whose_contact', isEqualTo: loggedInUser.email)
//         .get();
//     // Get data from docs and convert map to List
//     final allData = querySnapshot.docs.map((doc) {
//       // if (doc["email"] == 'bananaman@apple.com') {
//       // var key;
//       // print("this is name: " + doc['nickname']);
//       return doc.data();
//
//       //}
//     }).toList();
//     //var filteredData = filter(allData);
//     if (allData != null || allData.isNotEmpty) {
//       setState(() {
//         friendList = allData.toList();
//       });
//     }
//   }
//
//   getEmailList() {
//     for (int i = 0; i < friendList.length; i++) {
//       final email = friendList[i]['email'];
//       emailList.add(email);
//       setState(() {});
//     }
//   }
//
//
//   Stream<List<QuerySnapshot>> _mergedMessage() {
//     Stream<QuerySnapshot> stream1 = _fireStore
//         .collection('messages')
//         .where('sentto', isEqualTo: loggedInUser.email.toString())
//         .orderBy('senttime', descending: true)
//         .snapshots();
//     Stream<QuerySnapshot> stream2 = _fireStore
//         .collection('messages')
//         .where('sender', isEqualTo: loggedInUser.email.toString())
//         .orderBy('senttime', descending: true)
//         .snapshots();
//
//     return Rx.combineLatest2(stream1, stream2,
//             (QuerySnapshot a, QuerySnapshot b) {
//           List<QuerySnapshot> data = [];
//           data.add(a);
//           data.add(b);
//           return data;
//         });
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     Stream<QuerySnapshot> stream1 = _fireStore
//         .collection('messages')
//         .where('sentto', isEqualTo: loggedInUser.email.toString())
//         .orderBy('senttime', descending: true)
//         .snapshots();
//     Stream<QuerySnapshot> stream2 = _fireStore
//         .collection('messages')
//         .where('sender', isEqualTo: loggedInUser.email.toString())
//         .orderBy('senttime', descending: true)
//         .snapshots();
//     List<Stream<QuerySnapshot>> combineList = [stream1, stream2];
//
//     return SafeArea(
//       child: Scaffold(
//         // appBar: AppBar(
//         //   title: Row(
//         //     children: [
//         //       Text('Inbox'),
//         //       IconButton(
//         //           icon: Icon(Icons.people),
//         //           onPressed: () {
//         //             Navigator.push(
//         //                 context, MaterialPageRoute(builder: (context) => TestPage()));
//         //           }),
//         //     ],
//         //   ),
//         // ),
//
//           body: ModalProgressHUD(
//             inAsyncCall: spinner,
//             child: (emailList != [])
//                 ? Column(
//               children: [
//                 StreamBuilder<List<QuerySnapshot>>(
//                   stream: _mergedMessage(),
//                   builder: (context, snapshot) {
//                     List<Widget> inboxWidgets = [];
//                     List contactCount = [loggedInUser.email.toString()];
//                     String senderName;
//
//
//                     if (!snapshot.hasData) {
//                       return const Center(
//                         child: CircularProgressIndicator(
//                           backgroundColor: Colors.lightBlueAccent,
//                         ),
//                       );
//                     } else if (snapshot.hasData) {
//                       for (QuerySnapshot docs in snapshot.data!) {
//                         for (QueryDocumentSnapshot data in docs.docs) {
//                           var sender =data['sender'];
//                           var reciever = data['sentto'];
//                           var nameStamp;
//                           var messageSender;
//                           var messageReciever;
//                           var latestMessage=null;
//                           var latestSender;
//                           var latestTime;
//                           //to pick only the latest one only
//                           for (QuerySnapshot docss in snapshot.data!) {
//                             for (QueryDocumentSnapshot datas in docss.docs) {
//                               if((sender == datas['sender'] && reciever == datas['sentto'])||(reciever == datas['sender'] && sender == datas['sentto'])){
//                                 //khali huda naya data assign gardincha variable ma
//
//                                 Timestamp timestampDate= datas['senttime'];
//                                 var convertedtodate = timestampDate.toDate();
//                                 if(latestTime==null){
//                                   latestMessage=datas['messagetext'];
//                                   latestSender = datas['sender'];
//                                   latestTime=convertedtodate;
//
//                                 }
//                                 else{
//                                   //compare date
//                                   if(sender.toString()==loggedInUser.email.toString()){
//                                     isItMe=true;
//                                   }
//                                   else{isItMe=false;}
//                                   if(latestTime.compareTo(convertedtodate) < 0){
//                                     print("DT1 is before DT2");
//                                     latestTime=convertedtodate;
//                                     latestMessage = datas['messagetext'];
//                                     latestSender= datas['sender'];
//                                     messageSender= datas['sender'];
//                                     messageReciever=datas['sentto'];
//                                   }
//                                 }
//                               }
//                             }
//                           }
//                           log('this is the latest message $latestMessage' );
//                           // log(data['sender']);
//
//                           if(contactCount.contains(sender)==false || contactCount.contains(reciever)==false){
//                             final messageText = latestMessage;
//                             final finalSender= latestSender;
//
//                             if(sender.toString()==loggedInUser.email.toString()){
//                               nameStamp = data['sentto'];
//                             }
//                             else{
//                               nameStamp = data['sender'];
//                             }
//                             final messageSender = nameStamp;
//                             log('this is the message senderdsjfs'+messageSender);
//                             final inboxWidget = InboxContainer(
//                               name: messageSender, message: messageText, sender: finalSender,);
//                             inboxWidgets.add(inboxWidget);
//                             contactCount.add(sender);
//                           }
//                         }
//                       }
//                     }
//
//                     return Expanded(
//                         child: ListView(
//                           children: inboxWidgets,
//                         ));
//                   },
//                 ),
//               ],
//             )
//                 : Container(),
//           )),
//     );
//   }
// }
//
//
