import 'package:firebase_auth/firebase_auth.dart';
import 'package:flash_chat/screens/landing_page/landing_page.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import 'modules/constants.dart';

class TempLogin extends StatefulWidget {
  Function(User) onSignin;
  TempLogin({Key? key,required this.onSignin}) : super(key: key);

  @override
  State<TempLogin> createState() => _TempLoginState();
}

class _TempLoginState extends State<TempLogin> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  late String email;
  late String password;
  bool passwordVisibility = true;
  final _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            TextField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              textAlign: TextAlign.left,
              onChanged: (value) {
                email = value;
                //Do something with the user input.
              },

            ),
            TextFormField(
              obscureText: passwordVisibility,
              controller: passwordController,
              textAlign: TextAlign.left,
              onChanged: (value) {
                password = value;
                //Do something with the user input.
              },
              decoration: kLightTextField.copyWith(
                  contentPadding: EdgeInsets.only(top: 1.6.h),
                  prefixIcon: const Icon(Icons.lock),
                  suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          passwordVisibility = !passwordVisibility;
                        });
                      },
                      icon: Icon(passwordVisibility
                          ? Icons.visibility
                          : Icons.visibility_off)),
                  hintText: 'Enter your Password',
                  hintStyle: TextStyle(
                      fontSize: 10.sp,
                      color: Theme.of(context)
                          .textTheme
                          .headline1
                          ?.color
                          ?.withOpacity(0.5))),
              autovalidateMode: AutovalidateMode.onUserInteraction,
              validator: (value) {
                if (passwordController.text.length > 6) {
                  if (value == null || value.isEmpty || value.length < 6) {
                    return 'please provide a password with more than 6 characters';
                  } else {
                    return null;
                  }
                } else {
                  return null;
                }
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text('Login',style: TextStyle(fontSize: 12.sp),),
                loginButton(context),
              ],
            ),
          ],
        ),
      ),
    );
  }
  Padding loginButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Container(
        width: 100,
        height: 50,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Material(
          color: Theme
              .of(context)
              .primaryColor,
          borderRadius: const BorderRadius.all(Radius.circular(15.0)),
          elevation: 5.0,
          child: MaterialButton(
            onPressed: () async {
              if (emailController.text == '' || passwordController.text == '') {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    backgroundColor: Colors.grey.shade700,
                    content: Text(
                      'Please provide email and password',
                      style: GoogleFonts.lato(
                          textStyle: TextStyle(
                              color: Theme
                                  .of(context)
                                  .textTheme
                                  .headline1
                                  ?.color)),
                    )));
              } else {
                setState(() {
                  spinnerLogin = true;
                });
                signIn();
              }
            },
            // minWidth: 200.0,
            height: 36.0,
            child: const Icon(Icons.east, color: Colors.white),
          ),
        ),
      ),
    );
  }
  Future<void> signIn() async {
    try {
      UserCredential userCredential =  await _auth.signInWithEmailAndPassword(
          email: email, password: password);


      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => LandingPage(
                screen: 1,
              )));
      spinnerLogin=false;



    } on FirebaseAuthException catch (error) {
      String errorMessage = error.message.toString();
      Fluttertoast.showToast(msg: errorMessage, gravity: ToastGravity.TOP);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              backgroundColor: Colors.red.shade400,
              content: Text(
                errorMessage,
                style: GoogleFonts.lato(
                    textStyle: TextStyle(
                        color: Colors.white)),
              )));
      // setState(() {
      //   spinnerLogin = false;
      // });
    }
  }

}
