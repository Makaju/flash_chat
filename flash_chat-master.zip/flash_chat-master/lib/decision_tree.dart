import 'package:firebase_auth/firebase_auth.dart';
import 'package:flash_chat/screens/landing_page/landing_page.dart';
import 'package:flash_chat/screens/welcome_screen/welcome_screen.dart';
import 'package:flash_chat/tempLogin.dart';
import 'package:flutter/material.dart';

class DecisionTree extends StatefulWidget {
  const DecisionTree({Key? key}) : super(key: key);

  @override
  State<DecisionTree> createState() => _DecisionTreeState();
}

class _DecisionTreeState extends State<DecisionTree> {
  User? user;
  @override
  void initState(){
    super.initState();
    onRefresh(FirebaseAuth.instance.currentUser);
  }

  onRefresh(userCred) {
    setState(() {
      user = userCred;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (user == null) {
      return WelcomeScreen(
        onSignin: (userCred) => onRefresh(userCred),
      );
    } else {
      return LandingPage(screen: 1);
    }
  }
}
