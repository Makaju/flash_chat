import 'package:flutter/material.dart';
class ThemeProvider extends ChangeNotifier{

  ThemeMode themeMode = ThemeMode.light;
 bool get isDarkMode=>themeMode==ThemeMode.dark;



  void toggleTheme(bool isOn){

    themeMode = isOn?ThemeMode.dark:ThemeMode.light;
    notifyListeners();
  }
}
class MyThemes{
  static final darkTheme=ThemeData(
    scaffoldBackgroundColor: Colors.black,
    colorScheme: const ColorScheme.dark(secondary: Colors.black,onSecondary:Color(0x77424242)),
    primaryColor: Colors.purple,
    textTheme: const TextTheme(headline1: TextStyle(color: Colors.white)),
  );
  static final lightTheme=ThemeData(
    scaffoldBackgroundColor: Colors.white,
    primaryColor: const Color(0xFF1a0c89),
    colorScheme: const ColorScheme.light(secondary: Colors.white,onSecondary: Colors.white),
    textTheme: const TextTheme(headline1: TextStyle(color: Colors.black)),


  );
}