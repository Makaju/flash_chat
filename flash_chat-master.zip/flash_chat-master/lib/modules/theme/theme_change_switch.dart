import 'package:day_night_switcher/day_night_switcher.dart';
import 'package:flash_chat/modules/theme/theme_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ChangeThemeSwitchWidget extends StatefulWidget {
  const ChangeThemeSwitchWidget({Key? key}) : super(key: key);

  @override
  State<ChangeThemeSwitchWidget> createState() => _ChangeThemeSwitchWidgetState();
}

class _ChangeThemeSwitchWidgetState extends State<ChangeThemeSwitchWidget> {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    return DayNightSwitcher(
        isDarkModeEnabled: themeProvider.isDarkMode,
        onStateChanged: (value){setState(() {
          final provider = Provider.of<ThemeProvider>(context, listen: false);
          themeProvider.toggleTheme(value);

        });

        },
      );
  }
}
