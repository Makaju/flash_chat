// import 'package:flash_chat/screens/welcome_screen_old.dart';
// import 'package:flutter/material.dart';
//
// class RoundedButtonss extends StatelessWidget {
//   const RoundedButtonss(
//       {required this.colour,
//       required this.texts,
//       required this.onPressed,
//       Key? key})
//       : super(key: key);
//   final Color colour;
//   final String texts;
//   final GoToScreen onPressed;
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 16.0),
//       child: Material(
//         color: colour,
//         borderRadius: BorderRadius.circular(30.0),
//         elevation: 5.0,
//         child: MaterialButton(
//           onPressed: onPressed,
//           minWidth: 200.0,
//           height: 30.0,
//           child: Text(
//             texts,
//             style: const TextStyle(color: Colors.white),
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// class LandingPageOptions extends StatelessWidget {
//   const LandingPageOptions(
//       {required this.texts,
//       required this.icons,
//       required this.onPressed,
//       Key? key})
//       : super(key: key);
//
//   final String texts;
//   final Icon icons;
//   final GoToScreen onPressed;
//
//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: () {
//         onPressed();
//         // Navigator.push(context,  MaterialPageRoute(builder: (context)=>AddFriends(),));
//       },
//       child: Padding(
//         padding: const EdgeInsets.all(10.0),
//         child: Row(
//           children: [
//             icons,
//             Text(
//               '    $texts',
//               style: const TextStyle(fontSize: 20.0, color: Colors.black),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
