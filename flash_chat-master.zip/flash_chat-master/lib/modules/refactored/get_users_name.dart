// import 'dart:developer';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import '../global_variables.dart';
// import 'get_doc_id_for_contactlist_addnewcontact.dart';
// final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
// final _auth = FirebaseAuth.instance;
// late String usernameForPopup;
//
//
// Future<void> getUser() async {
//   try {
//     final user = _auth.currentUser;
//     if (user != null) {
//       loggedInUser = user;
//       userEmail=loggedInUser.email.toString();
//       userName=loggedInUser.displayName.toString();
//
//     }
//   } catch (e) {
//     log(e.toString());
//   }
// }
//
// Future<void> getUsersNameForPopup(String checkUsersEmail) async {
//   await getUser();
//   QuerySnapshot querySnapshot = await _fireStore.collection('userdetails').where('email' , isEqualTo: checkUsersEmail).get();
//   // Get data from docs and convert map to List
//   final allData = querySnapshot.docs.map((doc) {
//     if (doc["email"] == checkUsersEmail) {
//       // var key;
//       return doc['username'];
//     }
//   }).toList();
//   var filteredData = filter(allData);
//   usernameForPopup = filteredData;
//   log('here it gets name of user $filteredData');
//   return filteredData;
// }