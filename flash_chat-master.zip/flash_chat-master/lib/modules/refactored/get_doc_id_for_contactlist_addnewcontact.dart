// import 'dart:developer';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// import '../../screens/registration_page/profile_page.dart';
// import '../global_variables.dart';
//
// final _auth = FirebaseAuth.instance;
// final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
//
// Future<void> getUser() async {
//   try {
//     final user = _auth.currentUser;
//     if (user != null) {
//       loggedInUser = user;
//       userEmail=loggedInUser.email.toString();
//       userName=loggedInUser.displayName.toString();
//       // print(userName);
//       // print(loggedInUser.email);
//       // print(userEmail);
//     }
//   } catch (e) {
//     log(e.toString());
//   }
// }
// Future<void> getUsersName() async {
//   await getUser();
//   QuerySnapshot querySnapshot = await _fireStore.collection('userdetails').where('email' , isEqualTo: userEmail).get();
//   // Get data from docs and convert map to List
//   final allData = querySnapshot.docs.map((doc) {
//     if (doc["email"] == userEmail) {
//       // var key;
//       return doc['username'];
//     }
//   }).toList();
//   var filteredData = filter(allData);
//   nameofuser = filteredData;
//   log('here it gets name of user $filteredData');
//   return filteredData;
// }
//
//
//
// Future getEmailData() async {
//   await getUser();
//   // Get docs from collection reference
//   QuerySnapshot querySnapshot = await _fireStore.collection('contacts').get();
//   // Get data from docs and convert map to List
//   final allData = querySnapshot.docs.map((doc) {
//     if (doc["whosecontact"] == userEmail) {
//       // var key;
//       return doc.id;
//     }
//   }).toList();
//   var filteredData = filter(allData);
//   // log(filteredData);
//   return filteredData;
// }
//
// filter(List allData) {
//   for (int i = 0; i < allData.length; i++) {
//     if (allData[i] != null) {
//       return allData[i];
//     }
//   }
// }