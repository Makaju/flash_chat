import 'package:firebase_auth/firebase_auth.dart';
import 'package:flash_chat/modules/theme/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../screens/registration_page/storage_srvice.dart';

late User loggedInUser;
late String userEmail;
late String userName;
String? nameofuser;
final Storage storage = Storage();



themeGetter(BuildContext context) {
  if (Provider.of<ThemeProvider>(context).themeMode == ThemeMode.dark) {
    // isDarkModeDemo = true;
    return true;
  } else if (Provider.of<ThemeProvider>(context).themeMode !=
      ThemeMode.dark) {
    // isDarkModeDemo = false;
    return false;
  }
}