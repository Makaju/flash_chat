import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flash_chat/modules/global_variables.dart';

class DatabaseMethods {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List emailList = [];
  bool isFriend = false;
  List isFriendList = [];
  bool newaa = false;
  List isNotFriendList = [];

  findUserPosition(List users) {
    for (int t = 0; t < users.length; t++) {
      if (users[t] != users.toString()) {
        return t;
      }
    }
  }

  updatedCreateChatroom(String user, String reciever) async {
    isFriendList = [user];
    isNotFriendList = [];
    List users = [user, reciever];
    users.sort((a, b) => a.compareTo(b));
    // int userNumber=findUserPosition(users);
    await updatedGetFriendList(user, reciever).then((value) {
      if (value == true) {
        isFriendList.add(reciever);
        isFriendList.sort((a, b) => a.compareTo(b));
      } else {
        isNotFriendList.add(reciever);
        isNotFriendList.sort((a, b) => a.compareTo(b));
      }
    });

    // if(userNumber==0){isFriendList=[true,isFriend];}else{isFriendList=[isFriend,true];}
    final docChatroom =
        FirebaseFirestore.instance.collection('chat_room').doc();
    final json = {
      'id': docChatroom.id,
      'users': users,
      'isFriend': isFriendList,
      'isNotFriend': isNotFriendList,
      'isSeen': [false, false],
      'blocked': false,
      'blockedBy': '',
      'typingStatus':[false,false],
    };
    await docChatroom.set(json);
    return users;
  }

  createChatroom(String user, String reciever) async {
    String? docid;
    List users = [user, reciever];
    checkFriendshipStatus(user, reciever);
    users.sort((a, b) => a.compareTo(b));
    var listOfId = await retreavedocid(users);
    log('second log' + listOfId.toString());
    if (listOfId == [] || listOfId == null) {
      final docChatroom =
          FirebaseFirestore.instance.collection('chat_room').doc();
      docid = docChatroom.id;
      final json = {
        'id': docChatroom.id,
        'users': users,
        'isFriend': isFriend,
        'isSeen': [false, false],
        'blocked': false,
        'blocked_by': loggedInUser.email,
      };
      await docChatroom.set(json);
    }
    return docid;
  }

  getFriendsListOfReciever(String reciever) async {
    QuerySnapshot querySnapshot = await _firestore
        .collection('contact_details')
        .where('whose_contact', isEqualTo: reciever)
        .get();
    final allData = querySnapshot.docs.map((doc) {
      return doc.data();
    }).toList();
    if (allData != null || allData.isNotEmpty) {
      // setState(() {
      var friendList = allData.toList();
      return friendList;
      // });
    }
  }

  checkFriendshipStatus(String user, String reciever) {
    getFriendsListOfReciever(reciever).then((value) {
      for (int i = 0; i < value.length; i++) {
        final email = value[i]['email'];
        emailList.add(email);
      }
      if (emailList.contains(user)) {
        isFriend = true;
        newaa = true;
      } else {
        isFriend = false;
        newaa = false;
      }
    });
    return isFriend;
  }

  updatedGetFriendList(String user, String reciever) async {
    List emailList = [];
    QuerySnapshot querySnapshot = await _firestore
        .collection('contact_details')
        .where('whose_contact', isEqualTo: reciever)
        .get();
    final allData = querySnapshot.docs.map((doc) {
      return doc;
    }).toList();

    for (int i = 0; i < allData.length; i++) {
      emailList.add(allData[i]['email']);
    }
    if (emailList.contains(reciever)) {
      isFriend = true;
      return true;
    } else {
      isFriend = false;
      return false;
    }
  }

  retreavedocid(List users) async {
    // users.sort((a, b) => a.compareTo(b));
    var data = await _firestore
        .collection('chat_room')
        .where('users', isEqualTo: users)
        .get();

    var id = data.docs;
    if (id == [] || id == null || id.isEmpty) {
      log('null returned');
      return null;
    } else if (id != [] || id != null || id.isNotEmpty) {
      log('helookdos' + id.toString());
      var docId = id.first['id'];
      return docId;
    }
  }
}
