import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import '../screens/landing_page/profile_page/profile_page.dart';
import 'global_variables.dart';

class ContainerDemo extends StatefulWidget {
  ContainerDemo({Key? key, required this.sender, required this.message,required this.docId})
      : super(key: key);
  String sender;
  String message;
  String docId;

  @override
  State<ContainerDemo> createState() => _ContainerDemoState();
}

class _ContainerDemoState extends State<ContainerDemo> {
  var otherPerson;
  Future<void> getNameOfTheOtherParty(String docId)  async {

    var data = FirebaseFirestore.instance.collection('chat_room').doc(docId).get();
    var meow = await data.then((value) => value.get('users'));
    for(var i in meow) {
      if (i != loggedInUser.email.toString()) {
        toReturn = i.toString();
      }
    }
    log(toReturn.toString());

    setState(() {
      spinner=false;
    });

    log(meow.toString());
    // String otherOne =;
  }
  String? toReturn;
  bool spinner=true;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getNameOfTheOtherParty(widget.docId);
  }
  @override
  Widget build(BuildContext context) {
    // getNameOfTheOtherParty(docId);

    return  ModalProgressHUD(
      inAsyncCall: spinner,
      child: GestureDetector(
        onTap: (){
          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //         builder: (context) => ChatScreen(
          //           toWhom: 'ram@email.com',
          //         )));
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
height: 50,
            width: MediaQuery.of(context).size.width*0.7,
            decoration: BoxDecoration(
              color: Colors.grey,
              borderRadius: BorderRadius.circular(5)),
            padding: const EdgeInsets.all(8.0),
            child: Row(children: [
              profilePictureWidget(widget.sender.replaceAll('.', '') + '.jpg', 20.0),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16 ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [Text(widget.message),Text(toReturn.toString()),],
                ),
              )],),),
        ),
      ),

    )
    ;
  }
}
