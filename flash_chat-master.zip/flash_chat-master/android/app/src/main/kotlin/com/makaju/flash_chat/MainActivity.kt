package com.makaju.flash_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
